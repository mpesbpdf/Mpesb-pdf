MPESB PDF Notes – Starter Website

1. index.html को Chrome में खोलकर वेबसाइट का डेमो देखें।
2. यह एक static prototype है; PDF जोड़ने का demo admin form केवल उसी browser session में काम करता है।
3. Live public sales के लिए hosting, database/file storage, server-side order verification, payment gateway integration और secure download links चाहिए।
4. Payment success को केवल browser-side button से verify न करें। Gateway webhook/server verification अनिवार्य रखें।
5. केवल अपने बनाए हुए या बेचने की अनुमति वाले PDF अपलोड करें।
